/** FleetOps Pro — shared Apps Script backend for BOTH apps (driver.html + admin.html)
 *  Set ADMIN_KEY below. PINs and the admin key are checked HERE (server-side). */
const ADMIN_KEY = "change-me-admin";
const MEDIA_FOLDER = "FleetOps_Media";
const LOG_FIELDS = ["id","timestamp","driverId","driverName","busNumber","category","odoReading","expenseQty","expenseAmount","odoUrl","receiptUrl","location"];
const H = { Logs: LOG_FIELDS, Drivers: ["id","name","pin","r1","r2","r3","r4"], Buses: ["busNumber","note"] };

function out_(o){ return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }
function sh_(n){
  const ss = SpreadsheetApp.getActiveSpreadsheet(); let s = ss.getSheetByName(n);
  if(!s){ s = ss.insertSheet(n); s.getRange("A:Z").setNumberFormat("@"); s.appendRow(H[n]); s.setFrozenRows(1);
    if(n==="Drivers") s.appendRow(["D001","Demo Driver","1234"]);
    if(n==="Buses") s.appendRow(["BUS-01",""]); }
  return s;
}
function rows_(n){ const v = sh_(n).getDataRange().getValues(), h = v[0];
  return v.slice(1).map(r=>{ const o={}; h.forEach((k,i)=>o[k]=r[i]); return o; }); }
function img_(dataUrl, base){
  if(!dataUrl || dataUrl.indexOf(";base64,")<0) return "";
  const p = dataUrl.split(";base64,"), mime = p[0].replace(/^data:/,"") || "image/jpeg";
  const it = DriveApp.getFoldersByName(MEDIA_FOLDER), f = it.hasNext()? it.next() : DriveApp.createFolder(MEDIA_FOLDER);
  const file = f.createFile(Utilities.newBlob(Utilities.base64Decode(p[1]), mime, base+"_"+Date.now()+".jpg"));
  try{ file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); }catch(e){}
  return file.getUrl();
}
const RK = ["r1","r2","r3","r4"];
function rem_(x){ return RK.map(k=>String(x[k]||"")); }
function setRem_(id, times){
  const s = sh_("Drivers"), v = s.getDataRange().getValues(), h = v[0];
  RK.forEach(k=>{ if(h.indexOf(k)<0){ const c=h.length+1; s.getRange(1,c,s.getMaxRows(),1).setNumberFormat("@"); s.getRange(1,c).setValue(k); h.push(k); } });
  for(let i=1;i<v.length;i++){
    if(String(v[i][0]).toLowerCase()===String(id).toLowerCase()){
      s.getRange(i+1, h.indexOf("r1")+1, 1, 4).setValues([times]); return true; }
  }
  return false;
}
function lastOdo_(){ const m={};
  rows_("Logs").forEach(l=>{ const n=Number(l.odoReading), b=String(l.busNumber); if(b && !isNaN(n)) m[b]=Math.max(m[b]||0, n); });
  return m; }
const EDITABLE = ["odoReading","busNumber","category","expenseQty","expenseAmount"];
function editLog_(id, c){
  const s = sh_("Logs"), v = s.getDataRange().getValues(), h = v[0];
  if(h.indexOf("note")<0){ const k=h.length+1; s.getRange(1,k,s.getMaxRows(),1).setNumberFormat("@"); s.getRange(1,k).setValue("note"); h.push("note"); }
  const ii=h.indexOf("id"), ni=h.indexOf("note");
  for(let i=1;i<v.length;i++){
    if(String(v[i][ii])!==String(id)) continue;
    const ch=[];
    EDITABLE.forEach(f=>{ if(!(f in c)) return; const ci=h.indexOf(f), old=String(v[i][ci]), nw=String(c[f]);
      if(old!==nw){ s.getRange(i+1,ci+1).setValue(nw); ch.push(f+": "+old+" -> "+nw); } });
    if(ch.length){ const prev=v[i][ni]?v[i][ni]+" | ":"";
      s.getRange(i+1,ni+1).setValue(prev+"Admin edit "+new Date().toISOString()+" ["+ch.join("; ")+"]"); }
    return true;
  }
  return false;
}
function driver_(d){
  return rows_("Drivers").find(x=>String(x.id).toLowerCase()===String(d.driverId||"").toLowerCase() && String(x.pin)===String(d.pin||""));
}
// Public: bus list for the driver dropdown
function doGet(){ return out_({status:"success", buses: rows_("Buses").map(b=>String(b.busNumber))}); }

function doPost(e){
  try{
    const d = JSON.parse(e.postData.contents), a = d.action;
    if(a==="login"||a==="log"||a==="myLogs"){
      const drv = driver_(d);
      if(!drv) return out_({status:"error", message:"Invalid Driver ID or PIN"});
      if(a==="login") return out_({status:"success", driverName:drv.name, reminders:rem_(drv), lastOdo:lastOdo_()});
      if(a==="myLogs") return out_({status:"success", logs: rows_("Logs").filter(l=>String(l.driverId).toLowerCase()===String(drv.id).toLowerCase()).reverse().slice(0,50)});
      const last = lastOdo_()[String(d.busNumber)];
      if(last!==undefined && Number(d.odoReading) < last)
        return out_({status:"error", message:"Odometer "+d.odoReading+" km is lower than the last reading ("+last+" km) for "+d.busNumber});
      const tag = drv.id+"_"+(d.busNumber||"BUS");
      const odoUrl = img_(d.odoPhotoBase64, "ODO_"+tag), receiptUrl = img_(d.receiptPhotoBase64, "RCPT_"+tag);
      const id = "LOG-"+Date.now();
      sh_("Logs").appendRow([id, (d.capturedAt && !isNaN(Date.parse(d.capturedAt))) ? new Date(d.capturedAt).toISOString() : new Date().toISOString(), drv.id, drv.name, d.busNumber||"", d.category||"", d.odoReading||"", d.expenseQty||"", d.expenseAmount||"", odoUrl, receiptUrl, d.location||""]);
      return out_({status:"success", id:id, odoUrl:odoUrl, receiptUrl:receiptUrl});
    }
    if(d.adminKey !== ADMIN_KEY) return out_({status:"error", message:"Wrong admin key"});
    if(a==="logs") return out_({status:"success", logs: rows_("Logs").reverse(),
      drivers: rows_("Drivers").map(x=>({id:x.id,name:x.name,times:rem_(x)})), buses: rows_("Buses").map(x=>x.busNumber)});
    if(a==="addDriver"){
      if(!/^\d{4}$/.test(String(d.pin))) return out_({status:"error", message:"PIN must be 4 digits"});
      if(rows_("Drivers").some(x=>String(x.id).toLowerCase()===String(d.id).toLowerCase())) return out_({status:"error", message:"Driver ID exists"});
      sh_("Drivers").appendRow([d.id, d.name, d.pin]); return out_({status:"success"});
    }
    if(a==="editLog"){
      const c=d.changes||{};
      if("odoReading" in c && (String(c.odoReading).trim()===""||!(Number(c.odoReading)>=0))) return out_({status:"error", message:"Enter a valid odometer reading"});
      for(const k of ["expenseQty","expenseAmount"]) if(k in c && String(c[k]).trim()!=="" && !(Number(c[k])>=0)) return out_({status:"error", message:k+" must be a number"});
      if("busNumber" in c && !rows_("Buses").some(b=>String(b.busNumber)===String(c.busNumber))) return out_({status:"error", message:"Bus not registered"});
      return editLog_(d.id, c) ? out_({status:"success"}) : out_({status:"error", message:"Log not found"});
    }
    if(a==="setReminders"){
      const t = (d.times||[]).slice(0,4); while(t.length<4) t.push("");
      if(!t.every(x=>x===""||/^([01]\d|2[0-3]):[0-5]\d$/.test(x))) return out_({status:"error", message:"Times must be HH:MM"});
      return setRem_(d.id, t) ? out_({status:"success"}) : out_({status:"error", message:"Driver not found"});
    }
    if(a==="addBus"){
      if(rows_("Buses").some(x=>String(x.busNumber).toLowerCase()===String(d.busNumber).toLowerCase())) return out_({status:"error", message:"Bus exists"});
      sh_("Buses").appendRow([d.busNumber, d.note||""]); return out_({status:"success"});
    }
    return out_({status:"error", message:"Unknown action"});
  }catch(err){ return out_({status:"error", message:String(err)}); }
}
