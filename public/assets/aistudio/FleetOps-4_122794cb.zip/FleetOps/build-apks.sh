#!/usr/bin/env bash
# Builds TWO Android APKs: FleetOps-Driver.apk and FleetOps-Admin.apk
# Needs: Node 18+, JDK 17, Android SDK (ANDROID_HOME set; Android Studio installs it), internet.
# Run in this folder:  bash build-apks.sh
set -e
ROOT="$(pwd)"
build() {  # name  appId  title  html
  NAME=$1; ID=$2; TITLE=$3; SRC=$4
  rm -rf "build/$NAME"; mkdir -p "build/$NAME/www"; cp "$ROOT/$SRC" "build/$NAME/www/index.html"
  cd "build/$NAME"
  npm init -y >/dev/null
  npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/local-notifications >/dev/null
  npx cap init "$TITLE" "$ID" --web-dir www
  npx cap add android
  M=android/app/src/main/AndroidManifest.xml
  sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA"/><uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/><uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/><uses-permission android:name="android.permission.POST_NOTIFICATIONS"/><uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/><uses-feature android:name="android.hardware.camera" android:required="false"/><application#' "$M"
  npx cap sync android
  (cd android && ./gradlew assembleDebug)
  cp android/app/build/outputs/apk/debug/app-debug.apk "$ROOT/$TITLE.apk"
  cd "$ROOT"
}
build driver com.ava.fleetops.driver "FleetOps-Driver" driver.html
build admin  com.ava.fleetops.admin  "FleetOps-Admin"  admin.html
echo "Done: FleetOps-Driver.apk and FleetOps-Admin.apk"
